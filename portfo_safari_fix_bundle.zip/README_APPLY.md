# Safari / HTMX fix for `Gariix1/portfo`

This patch fixes the main Safari styling/navigation issues:

- Stops HTMX from injecting full HTML documents into `#mainContent`.
- Adds clean HTMX partials:
  - `content/partials/home.html`
  - `content/partials/service1.html`
- Replaces absolute `/content/...` routes with GitHub Pages-safe relative routes.
- Fixes broken `content/content/demos/...` links in `content/service1.html`.
- Replaces `background-attachment: fixed` with `scroll` to avoid Safari/iOS rendering bugs.
- Adds Safari/mobile viewport and `backdrop-filter` fallbacks.
- Adds a static Tailwind fallback for `demo2.html` while keeping the Tailwind CDN script.

## Apply

From the repo root:

```bash
git checkout main
git pull
git checkout -b fix/safari-styles-htmx
git apply portfo_safari_htmx_fix.patch
git status
git add .
git commit -m "Fix Safari styles and HTMX partial loading"
git push -u origin fix/safari-styles-htmx
```

Then open a PR into `main`.
